# Live2d看板娘
食用方法看这里，懒得在写一份 [给你的博客加上个Live2D看板娘吧](https://www.52ecy.cn/post-57.html "给你的博客加上个Live2D看板娘吧")
